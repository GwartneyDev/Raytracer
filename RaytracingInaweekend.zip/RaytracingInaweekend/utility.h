#ifndef UTILITY_H
#define UTILITY_H

 

#include <random>     // Ensures random number functions work
#include <glm.hpp> // Ensures GLM is included
#include <iostream>   // Ensures standard I/O works

// Constants
const double pi = 3.1415926535897932385;

// Utility Functions

// Convert degrees to radians
inline double degrees_to_radians(double degrees) {
    return degrees * pi / 180.0;
}

// Random number generation using std::mt19937
inline double random_double() {
    static std::random_device rd; // Seed generator
    static std::mt19937 gen(rd()); // Mersenne Twister generator
    static std::uniform_real_distribution<double> dis(0.0, 1.0); // Range [0, 1)
    return dis(gen);
}

// Generate a random double in [min, max)
inline double random_double(double min, double max) {
    return min + (max - min) * random_double();
}


glm::dvec3 random_vec3(double min, double max) {
    return glm::dvec3(
        random_double(min, max), // Random x
        random_double(min, max), // Random y
        random_double(min, max)  // Random z
    );

 
#endif // UTILITY_H

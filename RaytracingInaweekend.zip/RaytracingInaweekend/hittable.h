#include "ray.h"
#include "utility.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
 
#include "interval.h"

#ifndef HITTABLE_H
#define HITTABLE_H

using namespace std;

class hit_record{
  
    using vec3 = glm::dvec3;

    public:
        vec3 p;
        vec3 normal;
        double t;
        bool front_face;
        
        void set_face_normal(const ray& r, const vec3& outward_normal) {
            //Check if we are less than 0 meaning were negative
            //we are front facing in the right direction for the normal
            if (dot(r.direction(), outward_normal) < 0) {
                front_face = true;
                normal = outward_normal;
            } else {
                //other wise reverse the normal direction for the inside backfacing normal
                front_face = false;
                normal = -outward_normal;
            }
    }
    
};

class hittable {
    public:
    
    virtual ~hittable() = default;
        
    virtual bool hit(const ray& r, interval ray_t, hit_record& rec) const = 0;
    
};
#endif

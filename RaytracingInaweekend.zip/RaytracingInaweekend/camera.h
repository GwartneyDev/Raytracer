#ifndef CAMERA_H
#define CAMERA_H

#include "hittable.h"
#include "utility.h"
#include "ray.h"
#include "color.h"
#include <fstream>
#include <glm/glm.hpp>
#include <iostream>



class camera {
    
public:
    double aspect_ratio = 1.0;  // Ratio of the image width to height (e.g., 16.0 / 9.0 for widescreen).
    int image_width = 100;      // Width of the rendered image in pixels.
    int samples_per_pixel = 10; // Number of rays (samples) per pixel for anti-aliasing.

    // Main function to render the scene and output the image as a PPM file.
    void render(const hittable& world) {
        // Initialize camera parameters and calculate important values like pixel size.
        initialize();

        // Open a file stream to write the image data (in PPM format).
        std::ofstream outfile("/Users/alex/Desktop/raytracer/RaytracingInaweekend/output.ppm");

        // Write the PPM header.
        // "P3" means the image is in plain text.
        // Image dimensions are written as `image_width x image_height`.
        // "255" specifies the maximum color intensity.
        outfile << "P3\n" << image_width << " " << image_height << "\n255\n";

        // Loop through every pixel in the image grid, row by row.
        for (int j = 0; j < image_height; j++) {
            // Display progress in the terminal by printing how many rows remain.
            std::clog << "\rScanlines remaining: " << (image_height - j) << ' ' << std::flush;

            // For each row, process every column (left to right).
            for (int i = 0; i < image_width; i++) {
                // Initialize the pixel color accumulator to black (no color).
                color pixel_color(0, 0, 0);

                // Fire `samples_per_pixel` rays through the pixel for anti-aliasing.
                for (int sample = 0; sample < samples_per_pixel; sample++) {
                    // Generate a ray for this pixel with a random offset (jitter).
                    ray r = get_ray(i, j);

                    // Compute the color contribution for this ray and add it to the pixel's total color.
                    pixel_color += ray_color(r, world);
                }

                // Average the accumulated color by dividing by the number of samples.
                // Write the final averaged color to the output file.
                write_color(outfile, pixel_samples_scale * pixel_color);
            }
        }

        // Print a message to indicate that rendering is complete.
        std::clog << "\nRender complete.\n";
    }

private:
    int image_height;               // Height of the rendered image in pixels.
    double pixel_samples_scale;     // Scale factor for averaging samples per pixel.
    glm::dvec3 pixel00_loc;         // Top-left corner of the virtual image plane in 3D space.
    glm::dvec3 center;              // Position of the camera (usually the origin).
    glm::dvec3 pixel_delta_u;       // Horizontal step size per pixel in 3D space.
    glm::dvec3 pixel_delta_v;       // Vertical step size per pixel in 3D space.

    // Initialize camera parameters and compute values for ray tracing.
    void initialize() {
        // Compute the image height based on the aspect ratio.
        image_height = static_cast<int>(image_width / aspect_ratio);
        if (image_height < 1) image_height = 1; // Ensure the height is at least 1 pixel.

        // Compute the scale factor for averaging colors (1.0 divided by the number of samples).
        pixel_samples_scale = 1.0 / static_cast<double>(samples_per_pixel);

        // Camera setup:
        center = glm::dvec3(0, 0, 0); // Camera is positioned at the origin.

        // Define the dimensions of the viewport (in 3D space).
        double viewport_height = 2.0;                              // Fixed height of the viewport.
        double viewport_width = viewport_height * aspect_ratio;    // Adjust width based on aspect ratio.
        double focal_length = 1.0;                                // Distance from the camera to the image plane.

        // Compute horizontal and vertical directions of the viewport in 3D space.
        glm::dvec3 horizontal = glm::dvec3(viewport_width, 0, 0);
        glm::dvec3 vertical = glm::dvec3(0, -viewport_height, 0);

        // Calculate the position of the top-left corner of the viewport.
        pixel00_loc = center
                      - horizontal / 2.0          // Move to the left edge.
                      - vertical / 2.0            // Move to the top edge.
                      - glm::dvec3(0, 0, focal_length); // Move forward by the focal length.

        // Calculate the size of a single pixel in the viewport.
        pixel_delta_u = horizontal / static_cast<double>(image_width);
        pixel_delta_v = vertical / static_cast<double>(image_height);
    }

    
    // Generate a ray that passes through pixel (i, j) with a random offset for anti-aliasing.
       ray get_ray(int i, int j) const {
           // Random offset within the pixel bounds (for anti-aliasing).
           auto offset = sample_square();

           // Calculate the position of the sampled point on the image plane.
           auto pixel_sample = pixel00_loc
                               + ((i + offset.x) * pixel_delta_u) // Horizontal offset.
                               + ((j + offset.y) * pixel_delta_v); // Vertical offset.

           // The ray originates at the camera center and points towards the sampled pixel.
           auto ray_origin = center;
           auto ray_direction = glm::normalize(pixel_sample - ray_origin); // Normalize the direction.

           // Return the generated ray.
           return ray(ray_origin, ray_direction);
       }
    
    
    glm::dvec3 sample_square() const {
        // Returns a random point in the [-0.5, -0.5] - [+0.5, +0.5] unit square
        return glm::dvec3(random_double() - 0.5, random_double() - 0.5, 0);
    }

    
    
    // Calculate the color for a ray
    color ray_color(const ray& r, const hittable& world) const {
        hit_record rec;

        // Check if the ray hits any object in the scene.
        // If it does, the intersection details are stored in `rec`.
        if (world.hit(r, interval(0, infinity), rec)) {
            // `rec.normal` is the normal vector at the intersection point.
            // Add glm::dvec3(1.0, 1.0, 1.0) to shift the range of normals from [-1, 1] to [0, 2].
            // Multiply by 0.5 to scale the range to [0, 1], which is the valid color range.
            return 0.5 * (rec.normal + glm::dvec3(1.0, 1.0, 1.0));
        }

        // If the ray does not hit any object, compute a background color (sky gradient).

        // Normalize the ray's direction to get a unit vector.
        // This ensures the direction has a length of 1.
        glm::dvec3 unit_direction = glm::normalize(r.direction());

        // Map the y-component of the ray direction (range: [-1, 1]) to a value `t` in the range [0, 1].
        // This `t` determines how far the ray is pointing "upward":
        // - If the ray is pointing straight down (y = -1), t = 0.
        // - If the ray is pointing straight up (y = 1), t = 1.
        auto t = 0.5 * (unit_direction.y + 1.0);

        // Interpolate between white (1.0, 1.0, 1.0) and blue (0.5, 0.7, 1.0) based on `t`.
        // - At t = 0 (ray pointing down), the color is white.
        // - At t = 1 (ray pointing up), the color is blue.
        // - For values in between, the color is a blend of white and blue.
        return (1.0 - t) * color(1.0, 1.0, 1.0) // Contribution from white
               + t * color(0.5, 0.7, 1.0);     // Contribution from blue
    }

};

#endif


#include "ray.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "hittable.h"
#include "interval.h"
 
class hittable_list : public hittable {
    
using vectorHorizontalPosition = glm::vec3;
using vectorVerticalPosition = glm::vec3;
using vectorOrigin = glm::vec3;
    
public:
    std::vector<std::shared_ptr<hittable>> objects;

    hittable_list() {}
    
    hittable_list(shared_ptr<hittable> object) {
        add(object);
    }
    
    //Clear list
    void clear() {
        objects.clear();
    }
    
    void add(std::shared_ptr<hittable> object) {
        //add to end
        objects.push_back(object);
    }
    
    bool hit(const ray& r, interval ray_t, hit_record& rec) const override{
    
        
        //This is our temp_record of the intersection
        hit_record temp_rec;
        
        bool hit_anything = false;
        //Start at the furthest intersection point
        auto closest_so_far = ray_t.max;
        
        //loop through the list of objects
        for (const auto& object : objects) {
            if (object->hit(r, interval(ray_t.min, closest_so_far), temp_rec)){
                        //pjass in the values set true once we find intersection point
                        hit_anything = true;
                        //set the closest current point in the loop to the intersection point t
                        closest_so_far = temp_rec.t;
                        //update the record
                        rec = temp_rec;
                    }
                }
        

                return hit_anything;
    }
};

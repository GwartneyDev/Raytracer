#ifndef INTERVAL_H
#define INTERVAL_H

#include <limits> // For std::numeric_limits

// Define infinity using auto
auto infinity = std::numeric_limits<double>::infinity();

class interval {
public:
    double min, max;

    interval() : min(+infinity), max(-infinity) {} // Default interval is empty

    interval(double min, double max) : min(min), max(max) {}

    double size() const {
        return max - min;
    }

 
    bool contains(double x) const {
        return min <= x && x <= max;
    }

    //Ensures the hit point is with in a certain range
    bool surrounds(double x) const {
        return min < x && x < max;
    }
    
    //Used for sampling
    double clamp(double x) const {
        if (x < min) return min;  // If x is smaller than the minimum, return min.
        if (x > max) return max;  // If x is greater than the maximum, return max.
        return x;                 // If x is within [min, max], return x as is.
    }


    static const interval empty;
    static const interval universe;
};

// Static member initialization
const interval interval::empty = interval(+infinity, -infinity);
const interval interval::universe = interval(-infinity, +infinity);

#endif

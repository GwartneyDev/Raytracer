#include "utility.h"
#include "hittable_list.h"
#include "sphear.h"
#include "camera.h"
 
int main() {
 
    // World
    
    hittable_list world;
    
    world.add(make_shared<sphere>(vec3(0,0,-1),0.5));
    world.add(make_shared<sphere>(vec3(0,-100.5,-1), 100));
    
    camera cam;

   cam.aspect_ratio = 16.0 / 9.0;
    cam.image_width = 400;  // Higher resolution
    cam.samples_per_pixel = 100;  // Already set high, this is good

    
    cam.render(world);
    
    return 0;
}
    


 
     

   
 
